#!/bin/bash
cd 12.5nm
./packmol < ar8192.inp
cd ..
cd 11nm
./packmol < ar8192.inp
cd ..
cd 10.5nm
./packmol < ar8192.inp
cd ..
cd 14nm
./packmol < ar8192.inp
cd ..
cd 12nm
./packmol < ar8192.inp
cd ..
cd 13.5nm
./packmol < ar8192.inp
cd ..
cd 14.5nm
./packmol < ar8192.inp
cd ..
cd 13nm
./packmol < ar8192.inp
cd ..
cd 11.5nm
./packmol < ar8192.inp
cd ..
